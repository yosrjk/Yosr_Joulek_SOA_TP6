package org.example.Yosr_LSI3_SOA_TP6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YosrLsi3SoaTp6Application {

	public static void main(String[] args) {
		SpringApplication.run(YosrLsi3SoaTp6Application.class, args);
	}

}
