package org.example.Yosr_LSI3_SOA_TP6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YosrLsi3SoaTp6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
